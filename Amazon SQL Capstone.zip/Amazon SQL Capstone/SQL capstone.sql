--Using database amazon_sales
USE amazon_sales;

--Creating table amazon
CREATE TABLE amazon (
    invoice_id VARCHAR(30) NOT NULL,
    branch VARCHAR(5) NOT NULL,
    city VARCHAR(30) NOT NULL,
    customer_type VARCHAR(30) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    product_line VARCHAR(100) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,
    VAT FLOAT(6, 4) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    date DATE NOT NULL,
    time TIMESTAMP NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    cogs DECIMAL(10, 2) NOT NULL,
    gross_margin_percentage FLOAT(11, 9) NOT NULL,
    gross_income DECIMAL(10, 2) NOT NULL,
    rating FLOAT(2, 1) NOT NULL
);

select * from amazon;

ALTER TABLE amazon ADD timeofday VARCHAR(10);

UPDATE amazon
SET timeofday = CASE
    WHEN TIME(time) BETWEEN '06:00:00' AND '11:59:59' THEN 'Morning'
    WHEN TIME(time) BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
    ELSE 'Evening'
END;

SET SQL_SAFE_UPDATES = 0;

ALTER TABLE amazon ADD dayname VARCHAR(10);

UPDATE amazon
SET dayname = DAYNAME(date);

UPDATE amazon
SET date = STR_TO_DATE(date, '%d-%m-%Y')
WHERE date REGEXP '^[0-9]{2}-[0-9]{2}-[0-9]{4}$';

ALTER TABLE amazon ADD monthname VARCHAR(10);

UPDATE amazon
SET monthname = MONTHNAME(date);

select * from amazon;

--count of distinct cities in the dataset
SELECT COUNT(DISTINCT city) AS distinct_city_count
FROM amazon;

--For each branch, what is the corresponding city
SELECT branch, city
FROM amazon
GROUP BY branch, city;

--count of distinct product lines
SELECT COUNT(DISTINCT product_line) AS distinct_product_line_count;

--Most frequently occuring payment method
SELECT payment_method, COUNT(*) AS frequency
FROM amazon
GROUP BY payment_method
ORDER BY frequency DESC;

--Product line having highest sale
SELECT product_line, SUM(total) AS total_sales
FROM amazon
GROUP BY product_line
ORDER BY total_sales DESC;

--Revenue gemerated each month
SELECT DATE_FORMAT(date, '%m') AS month, 
SUM(total) AS monthly_revenue
FROM amazon
GROUP BY month
ORDER BY monthly_revenue DESC;

--In which month did the cost of goods sold reach its peak
SELECT DATE_FORMAT(date, '%m') AS month, 
SUM(cogs) AS total_cogs
FROM amazon
GROUP BY month
ORDER BY total_cogs DESC;

--Product line generating the highest revenue
SELECT product_line, SUM(total) AS total_revenue
FROM amazon
GROUP BY product_line
ORDER BY total_revenue DESC;

--City with the highest revenue
SELECT city, SUM(total) AS total_revenue
FROM amazon
GROUP BY city
ORDER BY total_revenue DESC;

--Which product line incurred the highest Value Added Tax
SELECT product_line, SUM(VAT) AS total_vat
FROM amazon
GROUP BY product_line
ORDER BY total_vat DESC;

--For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
SELECT product_line, SUM(total) AS total_sales,
    CASE 
        WHEN SUM(total) > (SELECT AVG(total) FROM amazon) THEN 'Good'
        ELSE 'Bad'
    END AS sales_performance
FROM amazon
GROUP BY product_line;

--Identify the branch that exceeded the average number of products sold.
SELECT branch, SUM(quantity) AS total_quantity_sold
FROM amazon
GROUP BY branch
HAVING SUM(quantity) > (SELECT AVG(total_quantity) FROM (SELECT SUM(quantity) AS total_quantity FROM amazon GROUP BY branch) AS avg_quantity);

--Which product line is most frequently associated with each gender?
SELECT gender, product_line, COUNT(*) AS frequency
FROM amazon
GROUP BY gender, product_line
ORDER BY gender, frequency DESC;

--average rating for each product line
SELECT product_line, AVG(rating) AS average_rating
FROM amazon
GROUP BY product_line;

--Count of sales occurrences for each time of day on every weekday
SELECT DAYNAME(date) AS weekday, 
    CASE 
        WHEN TIME(time) BETWEEN '06:00:00' AND '11:59:59' THEN 'Morning'
        WHEN TIME(time) BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
        ELSE 'Evening'
    END AS time_of_day,
    COUNT(*) AS sales_occurrences
FROM amazon
GROUP BY weekday, time_of_day
ORDER BY FIELD(weekday, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), time_of_day;


describe amazon;
SELECT DATABASE();

--customer type contributing the highest revenue.
SELECT `customer_ type`, SUM(total) AS total_revenue
FROM amazon
GROUP BY `customer_ type`
ORDER BY total_revenue DESC;

--city with the highest VAT percentage.
SELECT city, MAX(VAT) AS highest_vat_percentage
FROM amazon
GROUP BY city
ORDER BY highest_vat_percentage DESC ;

--customer type with the highest VAT payments
SELECT `customer_ type`, SUM(VAT) AS total_vat_paid
FROM amazon
GROUP BY `customer_ type`
ORDER BY total_vat_paid DESC;

--count of distinct customer types
SELECT COUNT(DISTINCT `customer_ type`) AS distinct_customer_types
FROM amazon;

--count of distinct payment methods
SELECT COUNT(DISTINCT payment_method) AS distinct_payment_methods
FROM amazon;

--customer type occurring most frequently
SELECT `customer_ type`, COUNT(*) AS frequency
FROM amazon
GROUP BY `customer_ type`
ORDER BY frequency DESC;

--customer type with the highest purchase frequency
SELECT `customer_ type`, COUNT(*) AS purchase_frequency
FROM amazon
GROUP BY `customer_ type`
ORDER BY purchase_frequency DESC;

--predominant gender among customers
SELECT gender, COUNT(*) AS gender_count
FROM amazon
GROUP BY gender
ORDER BY gender_count DESC;

--distribution of genders within each branch
SELECT branch, gender, COUNT(*) AS gender_count
FROM amazon
GROUP BY branch, gender
ORDER BY branch, gender_count DESC;

--time of day when customers provide the most ratings
SELECT timeofday, SUM(rating) AS total_ratings
FROM amazon
GROUP BY timeofday
ORDER BY total_ratings DESC;

--time of day with the highest customer ratings for each branch
SELECT branch, timeofday, SUM(rating) AS total_ratings
FROM amazon
GROUP BY branch, timeofday
ORDER BY branch, total_ratings DESC;

--day of the week with the highest average ratings
SELECT DAYNAME(date) AS day_of_week, AVG(rating) AS average_rating
FROM amazon
GROUP BY day_of_week
ORDER BY average_rating DESC;

--day of the week with the highest average ratings for each branch
SELECT branch, DAYNAME(date) AS day_of_week, AVG(rating) AS average_rating
FROM amazon
GROUP BY branch, day_of_week
ORDER BY branch, average_rating DESC;










